#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp

  // TODO: Declare any necessary private members
 private:
    long first_Jiffies{0};
    long first_ActJiffies{0}; 
    long second_Jiffies{0};
    long second_ActJiffies{0};
};

#endif